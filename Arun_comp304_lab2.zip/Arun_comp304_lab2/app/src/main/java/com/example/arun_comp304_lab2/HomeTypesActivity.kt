package com.example.arun_comp304_lab2

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity

class HomeTypesActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_types)
    }

    // This method is called when any of the buttons with android:onClick="onHomeTypeButtonClick" is clicked
    fun onHomeTypeButtonClick(view: View){
        // Handle the button click here
        val selectedHomeType = when (view.id) {
            R.id.apartmentButton -> "Apartment"
            R.id.detachedHomeButton -> "Detached Home"
            R.id.semiDetachedHomeButton -> "Semi-Detached Home"
            R.id.condominiumApartmentButton -> "Condominium Apartment"
            R.id.townHouseButton -> "Town House"
            else -> return
        }


        val intent = Intent(this,AvailableHomesActivity::class.java)
        intent.putExtra("homeType", selectedHomeType)
        startActivity(intent)
    }
}
