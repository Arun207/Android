package com.arun.arungopakumar_comp304lab5

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.arun.arungopakumar_comp304lab5.databinding.ActivityLandmarkMainBinding
import com.arun.arungopakumar_comp304lab5.model.LandmarkTypeAdapter

class LandmarkType : AppCompatActivity() {
    private lateinit var binding: ActivityLandmarkMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLandmarkMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val landmarkTypes = listOf("Old Buildings", "Museums", "Stadiums", "Attractions", "Parks and Gardens", "Entertainment District", "Shopping Districts", "Waterfront Sites", "Educational Institutions", "Cultural Hubs")
        // Setup RecyclerView
        val recyclerViewAdapter = LandmarkTypeAdapter(landmarkTypes) { selectedType ->
            navigateToLandmarkList(selectedType)
        }

        binding.recyclerView.layoutManager = GridLayoutManager(this,2)
        binding.recyclerView.adapter = recyclerViewAdapter
    }



    private fun navigateToLandmarkList(selectedType: String) {
        val intent = Intent(this, LandmarkListActivity::class.java)
        intent.putExtra("landmarkType", selectedType)
        startActivity(intent)
    }
}
