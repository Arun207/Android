package com.example.arun_comp304_lab2

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.EditText


class CardInfoActivity : AppCompatActivity() {

    private lateinit var submitCardInfoButton: Button
    private lateinit var cardNumberEditText: EditText
    private lateinit var fullNameEditText: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_card_info)

        // Initialize the UI elements by finding them using their IDs
        submitCardInfoButton = findViewById(R.id.submitCardInfoButton)
        cardNumberEditText = findViewById(R.id.cardNumberEditText)
        fullNameEditText = findViewById(R.id.fullNameEditText)

        // Handle "Submit Card Info" button click
        submitCardInfoButton.setOnClickListener {
            val cardNumber = cardNumberEditText.text.toString()
            val fullName = fullNameEditText.text.toString()

            // Check if card number and full name are valid
            if (isValidCardNumber(cardNumber) && isValidFullName(fullName)) {
                // Card information is valid, you can proceed with payment
                // Here, you can navigate to the payment confirmation screen
                val intent = Intent(this, UserInfoActivity::class.java)
                intent.putExtra("cardNumber", cardNumber)
                intent.putExtra("fullName", fullName)
                startActivity(intent)
            } else {
                // Display an error message or handle invalid input
            }
        }
    }

    private fun isValidCardNumber(cardNumber: String): Boolean {

        return true
    }

    private fun isValidFullName(fullName: String): Boolean {

        return true
    }
}

