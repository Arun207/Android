package com.arun.arungopakumar_comp304lab5

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import com.arun.arungopakumar_comp304lab5.databinding.ActivityLandmarkListBinding
import com.arun.arungopakumar_comp304lab5.model.Landmark
import com.arun.arungopakumar_comp304lab5.model.LandmarkListAdapter

class LandmarkListActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLandmarkListBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLandmarkListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val landmarkType = intent.getStringExtra("landmarkType")
        val landmarks = getLandmarksByType(landmarkType.orEmpty())

        val adapter = LandmarkListAdapter(landmarks) { selectedLandmark ->
            navigateToMap(selectedLandmark)
        }

        binding.landmarkRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.landmarkRecyclerView.adapter = adapter
    }

    private fun navigateToMap(selectedLandmark: Landmark) {
        val intent = Intent(this, MapActivity::class.java)
        intent.putExtra("selectedLandmark", selectedLandmark)
        startActivity(intent)
    }

    private fun getLandmarksByType(landmarkType: String): List<Landmark> {
        return when (landmarkType) {
            "Old Buildings" -> listOf(
                Landmark("Casa Loma", "1 Austin Terrace, Toronto", 43.678055, -79.409538),
                Landmark("Distillery Historic District", "55 Mill St, Toronto", 43.6506, -79.3597),
                Landmark("Fort York National Historic Site", "250 Fort York Blvd, Toronto", 43.6374, -79.4069),
                Landmark("St. Lawrence Hall", "157 King St E, Toronto", 43.6486, -79.3718)
            )

            "Museums" -> listOf(
                Landmark("Royal Ontario Museum", "100 Queens Park, Toronto", 43.6686, -79.3947),
                Landmark("Art Gallery of Ontario", "317 Dundas St W, Toronto", 43.6540, -79.3926),
                Landmark("Bata Shoe Museum", "327 Bloor St W, Toronto", 43.6674, -79.4003),
                Landmark("Aga Khan Museum", "77 Wynford Dr, Toronto", 43.7250, -79.3325)
            )

            "Stadiums" -> listOf(
                Landmark("Rogers Centre", "1 Blue Jays Way, Toronto", 43.6414, -79.3894),
                Landmark("Scotiabank Arena", "40 Bay St, Toronto", 43.6434, -79.3791),
                Landmark("BMO Field", "170 Princes' Blvd, Toronto", 43.6332, -79.4185),
                Landmark("Coca-Cola Coliseum", "45 Manitoba Dr, Toronto", 43.6323, -79.4186)
            )

            "Attractions" -> listOf(
                Landmark("CN Tower", "301 Front St W, Toronto", 43.6426, -79.3871),
                Landmark("Toronto Islands", "9 Queens Quay W, Toronto", 43.6205, -79.3792),
                Landmark("Ripley's Aquarium of Canada", "288 Bremner Blvd, Toronto", 43.6424, -79.3857),
                Landmark("High Park", "1873 Bloor St W, Toronto", 43.6465, -79.4632)

            )

            "Parks and Gardens" -> listOf(
                Landmark("High Park", "1873 Bloor St W, Toronto", 43.6465, -79.4632),
                Landmark("Toronto Botanical Garden", "777 Lawrence Ave E, Toronto", 43.7342, -79.3761),
                Landmark("Edwards Gardens", "755 Lawrence Ave E, Toronto", 43.7344, -79.3581),
                Landmark("Trinity Bellwoods Park", "790 Queen St W, Toronto", 43.6471, -79.4137)
            )

            "Entertainment District" -> listOf(
                Landmark("Roy Thomson Hall", "60 Simcoe St, Toronto", 43.6466, -79.3857),
                Landmark("Princess of Wales Theatre", "300 King St W, Toronto", 43.6468, -79.3898),
                Landmark("Rogers Centre", "1 Blue Jays Way, Toronto", 43.6414, -79.3894),
                Landmark("TIFF Bell Lightbox", "350 King St W, Toronto", 43.6466, -79.3902)
            )

            "Shopping Districts" -> listOf(
                Landmark("Yorkville Village", "55 Avenue Rd, Toronto", 43.6705, -79.3935),
                Landmark("Eaton Centre", "220 Yonge St, Toronto", 43.6545, -79.3800),
                Landmark("Distillery Historic District", "55 Mill St, Toronto", 43.6506, -79.3597),
                Landmark("Bloor-Yorkville", "Yorkville Ave, Toronto", 43.6702, -79.3914)
            )

            "Waterfront Sites" -> listOf(
                Landmark("Toronto Islands", "9 Queens Quay W, Toronto", 43.6205, -79.3792),
                Landmark("Sugar Beach", "25 Dockside Dr, Toronto", 43.6434, -79.3687),
                Landmark("Harbourfront Centre", "235 Queens Quay W, Toronto", 43.6383, -79.3807),
                Landmark("Humber Bay Arch Bridge", "Lake Shore Blvd W, Toronto", 43.6185, -79.4776)
            )

            "Educational Institutions" -> listOf(
                Landmark("University of Toronto", "27 King's College Cir, Toronto", 43.6629, -79.3957),
                Landmark("Ryerson University", "350 Victoria St, Toronto", 43.6577, -79.3788),
                Landmark("York University", "4700 Keele St, Toronto", 43.7738, -79.5016),
                Landmark("George Brown College", "160 Kendal Ave, Toronto", 43.6513, -79.3673)
            )

            "Cultural Hubs" -> listOf(
                Landmark("Royal Conservatory of Music", "273 Bloor St W, Toronto", 43.6683, -79.3963),
                Landmark("Art Gallery of Ontario", "317 Dundas St W, Toronto", 43.6540, -79.3926),
                Landmark("The Aga Khan Museum", "77 Wynford Dr, Toronto", 43.7250, -79.3325),
                Landmark("Royal Ontario Museum", "100 Queens Park, Toronto", 43.667679, -79.394809)
            )

            else -> emptyList()
        }
    }
}
