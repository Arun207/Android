package com.arun.arungopakumar_comp304lab5.model

import android.util.Log
import android.view.LayoutInflater

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.arun.arungopakumar_comp304lab5.databinding.ItemLandmarkTypeBinding

class LandmarkTypeAdapter(
    private val landmarkTypes: List<String>,
    private val onItemClick: (String) -> Unit
) : RecyclerView.Adapter<LandmarkTypeAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemLandmarkTypeBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val landmarkType = landmarkTypes[position]
        holder.bind(landmarkType)
        holder.itemView.setOnClickListener { onItemClick(landmarkType) }
        Log.d("LandmarkTypeAdapter", "landmarkTypes: $landmarkTypes, position: $position")
    }

    override fun getItemCount(): Int {
        return landmarkTypes.size
    }

    class ViewHolder(private val binding: ItemLandmarkTypeBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(landmarkType: String) {
            binding.landmarkType.text = landmarkType
        }
    }
}
