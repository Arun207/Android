package com.example.arun_comp304_lab2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.RadioGroup
import androidx.appcompat.app.AppCompatActivity

class PaymentOptionsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payment_options)

        val paymentRadioGroup = findViewById<RadioGroup>(R.id.paymentRadioGroup)
        val continueButton = findViewById<Button>(R.id.confirmPaymentButton)

        continueButton.setOnClickListener {
            val selectedPaymentOptionId = paymentRadioGroup.checkedRadioButtonId
            when (selectedPaymentOptionId) {
                R.id.creditCardRadioButton, R.id.debitCardRadioButton -> {
                    // Handle the selection of credit card or debit card
                    val intent = Intent(this, CardInfoActivity::class.java)
                    startActivity(intent)
                }
                R.id.cashRadioButton -> {
                    // Handle the selection of cash payment
                    val intent = Intent(this, UserInfoActivity::class.java)
                    startActivity(intent)
                }
                else -> {

                }
            }
        }
    }
}
