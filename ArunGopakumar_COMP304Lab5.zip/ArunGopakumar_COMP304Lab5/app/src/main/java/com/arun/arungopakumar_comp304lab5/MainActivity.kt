package com.arun.arungopakumar_comp304lab5

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Find the "Ready to Explore" button by its ID
        val readyToExploreButton: Button = findViewById(R.id.readyToExploreButton)

        // Set a click listener for the button
        readyToExploreButton.setOnClickListener {
            // Handle button click, for example, navigate to another activity
            val intent = Intent(this,LandmarkType::class.java)
            startActivity(intent)
        }
    }
}
