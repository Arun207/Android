package com.arun.arungopakumar_comp304lab5.model

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.arun.arungopakumar_comp304lab5.databinding.ItemLandmarkBinding

class LandmarkListAdapter(
    private val landmarks: List<Landmark>,
    private val onItemClick: (Landmark) -> Unit
) : RecyclerView.Adapter<LandmarkListAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemLandmarkBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val landmark = landmarks[position]
        holder.bind(landmark)
        holder.itemView.setOnClickListener { onItemClick(landmark) }
    }

    override fun getItemCount(): Int = landmarks.size

    class ViewHolder(private val binding: ItemLandmarkBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(landmark: Landmark) {
            binding.landmarkName.text = landmark.name
            binding.landmarkAddress.text = landmark.address
        }
    }
}