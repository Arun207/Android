package com.example.arun_comp304_lab2


import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class AvailableHomesActivity : AppCompatActivity() {
    private var selectedMenuItems = mutableListOf<String>() // Track selected menu item names
    private var selectedHouseTypes = mutableListOf<String>()
    private var availableHomesList = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_available_homes)

        // Initialize the views by finding them using their IDs
        val availableHomesListView = findViewById<ListView>(R.id.availableHomesListView)
        val continueButton = findViewById<Button>(R.id.continueButton)

        // Set up an adapter to display the list of available homes
        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_multiple_choice,
            availableHomesList
        )
        availableHomesListView.adapter = adapter

        // Handle "Continue" button click
        // Handle "Continue" button click
        continueButton.setOnClickListener {
            val intent = Intent(this, CheckoutActivity::class.java)

            // Pass the selected home addresses to the next activity
            val selectedHomes = availableHomesListView.checkedItemPositions
            val selectedHomeAddresses = mutableListOf<String>()

            // Collect the content of selected checkboxes
            for (i in 0 until availableHomesList.size) {
                if (selectedHomes[i]) {
                    selectedHomeAddresses.add(availableHomesList[i].substringAfter("Address 1: "))
                }
            }

            // Pass the content of selected checkboxes to CheckoutActivity
            intent.putStringArrayListExtra("selectedMenuItems", ArrayList(selectedHomeAddresses))
            startActivity(intent)
        }


    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.home_types_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menu_apartment,
            R.id.menu_detached_home,
            R.id.menu_semi_detached_home,
            R.id.menu_condo_apartment,
            R.id.menu_town_house -> {
                val houseType = item.title.toString()
                if (!selectedMenuItems.contains(houseType)) {
                    selectedMenuItems.add(houseType)
                    updateAvailableHomes(houseType) // Update the list based on the selected home type
                }
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }

    private fun updateAvailableHomes(selectedType: String) {
        // Clear the list and add homes based on the selected type
        availableHomesList.clear()
        // Add homes based on selectedType, you can customize this logic
        availableHomesList.add("Address 1: $selectedType Home, $1000/month")
        availableHomesList.add("Address 2: $selectedType Home, $1200/month")
        availableHomesList.add("Address 3: $selectedType Home, $1500/month")
        availableHomesList.add("Address 4: $selectedType Home, $1700/month")
        availableHomesList.add("Address 5: $selectedType Home, $1400/month")

        // Notify the adapter that the data has changed
        val adapter = findViewById<ListView>(R.id.availableHomesListView).adapter as ArrayAdapter<*>
        adapter.notifyDataSetChanged()
    }
}
