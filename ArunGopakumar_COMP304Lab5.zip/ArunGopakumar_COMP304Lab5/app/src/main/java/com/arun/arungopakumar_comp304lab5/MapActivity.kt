package com.arun.arungopakumar_comp304lab5

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.arun.arungopakumar_comp304lab5.databinding.ActivityMapBinding
import com.arun.arungopakumar_comp304lab5.model.Landmark
import com.google.android.gms.maps.*
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions

class MapActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var binding: ActivityMapBinding
    private lateinit var mapView: MapView
    private lateinit var googleMap: GoogleMap
    private var selectedLandmark: Landmark? = null
    private var marker: Marker? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMapBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.title = "Map"
        // Retrieve selected landmark from intent
        selectedLandmark = intent.getParcelableExtra<Landmark>("selectedLandmark")


        mapView = binding.mapView
        mapView.onCreate(savedInstanceState)
        mapView.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        this.googleMap = googleMap

        // Add a marker for the selected landmark
        selectedLandmark?.let { landmark ->
            val markerPosition = LatLng(landmark.latitude, landmark.longitude)
            marker = googleMap.addMarker(
                MarkerOptions()
                    .position(markerPosition)
                    .title(landmark.name)
            )

            // Move the camera to the selected landmark
            val cameraPosition = CameraPosition.Builder()
                .target(markerPosition)
                .zoom(15.0f)  // You can adjust the zoom level here
                .build()

            googleMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition))
        }


        // Set up map click listener for adding new markers
        googleMap.setOnMapClickListener { latLng ->
            // Remove the existing marker (if any)
            marker?.remove()

            // Add a new marker at the clicked location
            marker = googleMap.addMarker(MarkerOptions().position(latLng).title("New Marker"))
        }
    }
    // Click handler for Hybrid button
    fun onHybridButtonClick(view: View) {
        googleMap.mapType = GoogleMap.MAP_TYPE_NORMAL
    }

    // Click handler for Satellite button
    fun onSatelliteButtonClick(view: View) {
        googleMap.mapType = GoogleMap.MAP_TYPE_HYBRID
    }

    override fun onStart() {
        super.onStart()
        mapView.onStart()
    }

    override fun onResume() {
        super.onResume()
        mapView.onResume()
    }

    override fun onPause() {
        super.onPause()
        mapView.onPause()
    }

    override fun onStop() {
        super.onStop()
        mapView.onStop()
    }

    override fun onDestroy() {
        super.onDestroy()
        mapView.onDestroy()
    }

    override fun onLowMemory() {
        super.onLowMemory()
        mapView.onLowMemory()
    }
}
