package com.example.arun_comp304_lab2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.appcompat.app.AppCompatActivity

class CheckoutActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_checkout)

        // Retrieve the selected home addresses from the intent
        val selectedHomeAddresses = intent.getStringArrayListExtra("selectedMenuItems")

        // Find the RadioGroup in the layout
        val radioGroup = findViewById<RadioGroup>(R.id.radioGroup)

        // Dynamically create RadioButtons for each selected home address
        selectedHomeAddresses?.forEach { address ->
            val radioButton = RadioButton(this)
            radioButton.text = address
            radioGroup.addView(radioButton)
        }
        val checkoutButton = findViewById<Button>(R.id.checkoutButton)
       checkoutButton.setOnClickListener {
            val intent = Intent(this, PaymentOptionsActivity::class.java)
            startActivity(intent)
        }

    }
}

