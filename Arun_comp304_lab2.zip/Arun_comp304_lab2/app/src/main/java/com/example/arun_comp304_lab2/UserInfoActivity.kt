package com.example.arun_comp304_lab2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class UserInfoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_info)

        val saveButton = findViewById<Button>(R.id.saveButton)
        val fullNameEditText = findViewById<EditText>(R.id.fullNameEditText)

        saveButton.setOnClickListener {
            // Handle "Save" button click
            val fullName = fullNameEditText.text.toString()

        }
        saveButton.setOnClickListener {
            // Handle "Save" button click
            // Display a Toast message when submitted
            val message = "Submitted"
            val intent =Intent(this, HomeTypesActivity::class.java)
            startActivity(intent)
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        }

    }
}
