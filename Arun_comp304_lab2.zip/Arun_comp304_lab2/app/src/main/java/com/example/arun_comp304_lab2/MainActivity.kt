package com.example.arun_comp304_lab2
import androidx.appcompat.app.AppCompatActivity
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.widget.Toolbar
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val enterButton = findViewById<Button>(R.id.enterButton)

        // Find the toolbar by its ID
        val toolbar = findViewById<Toolbar>(R.id.toolbar)

        // Set the toolbar as the support action bar
        setSupportActionBar(toolbar)

        // Handle "Enter" button click
        enterButton.setOnClickListener {
            val intent = Intent(this, HomeTypesActivity::class.java)
            startActivity(intent)
        }
    }
}
